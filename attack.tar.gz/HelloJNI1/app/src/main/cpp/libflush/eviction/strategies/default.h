/* See LICENSE file for license and copyright information */

/* Default example configuration */
#define NUMBER_OF_SETS 4096
#define LINE_LENGTH_LOG2 6
#define LINE_LENGTH 64
#define ES_EVICTION_COUNTER 28
#define ES_NUMBER_OF_ACCESSES_IN_LOOP 5
#define ES_DIFFERENT_ADDRESSES_IN_LOOP 4
